"""Service Layer for Server Manager Application

This package contains business logic and service classes:
- Server management service
- Configuration service
- Process management service
"""