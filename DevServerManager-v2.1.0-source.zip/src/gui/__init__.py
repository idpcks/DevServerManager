"""GUI Components for DevServer Manager Application

This package contains all GUI-related components including:
- Main window
- Dialogs
- Custom widgets
- Splash screen
"""