"""Data Models for Server Manager Application

This package contains data models and structures:
- Server configuration model
- Application settings model
- Theme configuration model
"""