"""Utility Functions and Helpers

This package contains utility functions and helper classes:
- Theme manager
- Configuration helpers
- File system utilities
- Logging utilities
"""